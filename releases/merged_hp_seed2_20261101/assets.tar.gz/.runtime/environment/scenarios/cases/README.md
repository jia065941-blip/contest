# 竞赛场景

当前默认使用 `launch20/` 中的连续自由部署场景。`final20/` 提供网格部署场景；`final24/` 和直接位于 `easy/`、`medium/`、`hard/` 的九图场景作为可选地图保留，各套地图使用自身的资源与计分配置。

每个案例包含：

- `scenario.json`：仿真器直接读取的场景；
- `case_info.json`：目标、时限与场景校验信息；
- `map_info.png`：不含推荐航迹、发射顺序或目标分配的信息图。

本目录的 `manifest.json` 记录九图场景；其他场景集的索引位于对应子目录。`reward.py` 统一按完整摧毁计分：母巢、哨卫巢、暗巢权重分别为5、2、1，血量归零的目标获得其权重，存活目标得零分；总分为已摧毁权重占全部目标权重的百分比。`K`与`raw_score`记录该占比，`T`恒为零。运行单个案例：

```powershell
python main.py --scenario launch20/easy/E01 --total-rounds 1 --render-mode none
```
