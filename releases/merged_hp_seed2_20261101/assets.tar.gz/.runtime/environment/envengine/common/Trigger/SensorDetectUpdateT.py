# -*- coding: utf-8 -*-#
# Version:8, Last Modified time: 2023/10/18 18:14:20.
# Created by Administrator on 2026/05/18 14:50:47.
# Copyright (c) 2023 SiYuanHongRui All rights reserved.
#

from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from ..BaseStruct import *


@dataclass_json
@dataclass
class SensorDetectUpdateT:
	# 探测器探测结果更新事件
	event: SensorDetectUpdateTrigger = field(default_factory=SensorDetectUpdateTrigger)
