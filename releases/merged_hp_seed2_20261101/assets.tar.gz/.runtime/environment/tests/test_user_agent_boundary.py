"""Keep decisions in per-entity agents and learning orchestration in examples."""

import ast
from copy import deepcopy
import inspect
from pathlib import Path
import unittest
from unittest.mock import Mock, patch

import numpy as np

from envengine.agent_manager import AgentManager
from envengine.environment.training_env import TrainingEnv
from user_agents.red import AttackMissileAgent, RedAgentConfig, RedAgentFactory, RedBaselineCommander


ROOT = Path(__file__).resolve().parents[1]
PUBLIC = {"entities": {
    101: {"type": 9400, "position": {"lon": 119.0, "lat": 22.0}},
}}


def observation(entity_id=1, *, step=1, peers=()):
    return {
        "step": step, "agent_id": entity_id, "entity_id": entity_id,
        "self": {
            "type": 21000, "health": 100, "isVisible": True,
            "position": {"lon": 118.0, "lat": 22.0, "alt": 3000},
            "detectInfo": {}, "commRangeInfo": {peer: {} for peer in peers},
        },
    }


class UserAgentBoundaryTests(unittest.TestCase):
    def test_public_constructor_and_factory_accept_only_user_data(self):
        self.assertEqual(list(inspect.signature(AttackMissileAgent).parameters),
                         ["agent_id", "entity_id", "init_observation"])
        self.assertEqual(list(inspect.signature(RedAgentFactory).parameters), ["config"])
        self.assertEqual(list(inspect.signature(RedAgentFactory.create_agents).parameters),
                         ["self", "public_observation", "platforms", "search_polygon"])
        factory = RedAgentFactory(RedAgentConfig(motion_policy="straight"))
        first, second = factory.create_agents(deepcopy(PUBLIC), ((1, 1), (2, 2)))
        self.assertFalse(hasattr(first, "set_commander"))
        first.init_observation["entities"][101]["position"]["lon"] = 999
        self.assertEqual(second.init_observation["entities"][101]["position"]["lon"], 119.0)
        self.assertEqual(PUBLIC["entities"][101]["position"]["lon"], 119.0)

    def test_framework_has_no_example_planning_or_learning_hooks(self):
        for name in ("set_team_controller_factory", "set_shared_learning_policy",
                     "set_agent_runtime", "_prepare_team_controllers"):
            self.assertFalse(hasattr(TrainingEnv, name), name)
        tree = ast.parse((ROOT / "envengine/environment/training_env.py").read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                self.assertFalse((node.module or "").startswith("user_agents.red"))
            if isinstance(node, ast.Attribute):
                self.assertNotIn(node.attr, {
                    "_team_controllers", "_team_controller_factory", "_shared_learning_policy",
                    "_agent_runtime", "prepare_observation", "begin_environment_step",
                    "end_environment_step", "finish_environment_step",
                })
        for file in ("main.py", "user_agents/red/factory.py"):
            tree = ast.parse((ROOT / file).read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    if file == "main.py":
                        self.assertNotIn(node.func.id, {
                            "AttackMissileAgent", "RedBaselineCommander", "build_learning_motion_policy",
                        })
                if file.endswith("factory.py") and isinstance(node, ast.ImportFrom):
                    self.assertFalse((node.module or "").startswith("envengine"))

    def test_set_observation_only_reports_and_get_action_performs_planning(self):
        factory = RedAgentFactory(RedAgentConfig(motion_policy="straight", seed=7))
        first, second = factory.create_agents(deepcopy(PUBLIC), ((1, 1), (2, 2)))
        with patch.object(RedBaselineCommander, "begin_step", autospec=True,
                          side_effect=RedBaselineCommander.begin_step) as plan:
            first.set_observation(observation(1, peers=(2,)))
            second.set_observation(observation(2, peers=(1,)))
            self.assertEqual(plan.call_count, 0)
            self.assertEqual((first.launch_step, second.launch_step), (-1, -1))
            actions = first.get_action()
            self.assertEqual(plan.call_count, 1)
            self.assertEqual({item["entity_id"] for item in plan.call_args.args[1]}, {1, 2})
            second.get_action()
            self.assertEqual(plan.call_count, 1)
        self.assertEqual(list(actions[0]), [4, 1, 101, 0])
        self.assertIs(first._commander, second._commander)
        self.assertEqual((first.launch_step, second.launch_step), (1, 1))

    def test_precomputed_action_payload_does_not_replace_agent_decision(self):
        agent = AttackMissileAgent(1, 1, deepcopy(PUBLIC))
        local = observation()
        local["example_decision"] = {
            "actions": [[4, 1, 999, 0]],
            "state": {"launch_step": 999, "sat_used": True},
        }
        agent.set_observation(local)
        actions = agent.get_action()
        self.assertEqual(int(actions[0, 2]), 101)
        self.assertEqual(agent.launch_step, 1)

    def test_local_mailbox_cannot_submit_another_platforms_report(self):
        factory = RedAgentFactory(RedAgentConfig(motion_policy="straight"))
        first, _ = factory.create_agents(deepcopy(PUBLIC), ((1, 1), (2, 2)))
        with self.assertRaisesRegex(ValueError, "own observation"):
            first.set_observation(observation(2))
        first.set_observation(observation(1))
        self.assertEqual(int(first.get_action()[0, 1]), 1)

    def test_reset_all_discards_group_mailboxes_and_previous_target_memory(self):
        factory = RedAgentFactory(RedAgentConfig(motion_policy="straight"))
        agents = factory.create_agents(deepcopy(PUBLIC), ((1, 1), (2, 2)))
        manager = AgentManager()
        for agent in agents:
            manager.register_agent(agent)
        observations = {i: observation(i, peers=(3 - i,)) for i in (1, 2)}
        for local in observations.values():
            local["self"]["detectInfo"][103] = {
                "entity_id": 103, "entity_type": 9500, "time": 1,
                "lla": {"x": 119.5, "y": 22, "z": 0},
            }
        manager.collect_actions_from_agents(observations)
        previous = agents[0]._commander
        self.assertIn(103, {item.entity_id for item in previous.targets})
        manager.reset_all()
        self.assertEqual([agent.launch_step for agent in agents], [-1, -1])
        manager.collect_actions_from_agents({i: observation(i, step=0) for i in (1, 2)})
        self.assertIsNot(agents[0]._commander, previous)
        self.assertNotIn(103, {item.entity_id for item in agents[0]._commander.targets})
        self.assertIsNot(agents[0]._commander, agents[1]._commander)

    def test_actor_and_record_step_expose_only_local_training_calls(self):
        policy = Mock(training=True)
        policy.select_action.return_value = 1
        with patch("user_agents.red.factory.build_learning_motion_policy", return_value=policy):
            factory = RedAgentFactory(RedAgentConfig(motion_policy="ppo", training=True))
        agent = factory.create_agents(deepcopy(PUBLIC), ((1, 1),))[0]
        for name in ("get_global_state_context", "begin_environment_step", "end_environment_step",
                     "finish_environment_step", "observe"):
            self.assertFalse(hasattr(agent._actor, name), name)
        agent.set_observation(observation())
        action = agent.get_action()
        agent.record_step(observation(step=2), action, 1.0, {"done": False})
        policy.select_action.assert_called_once()
        self.assertEqual(policy.select_action.call_args.args[0].shape, (85,))
        self.assertEqual(len(factory._transitions), 1)
        for name in ("get_global_state_context", "begin_environment_step", "end_environment_step",
                     "finish_environment_step", "observe"):
            getattr(policy, name).assert_not_called()
        transition = factory._transitions[0]
        self.assertIsNone(transition.global_state)
        self.assertIsNone(transition.next_global_state)
        self.assertTrue(np.isfinite(transition.observation).all())

    def test_training_runner_pairs_each_frames_local_reports_with_its_global_states(self):
        policy = Mock(training=True)
        policy.select_action.return_value = 1
        states = [(np.full(70, step), np.full(70, step + 1)) for step in (1, 2)]
        policy.get_global_state_context.side_effect = states
        with patch("user_agents.red.factory.build_learning_motion_policy", return_value=policy):
            factory = RedAgentFactory(RedAgentConfig(motion_policy="ppo", training=True))
        agents = factory.create_agents(deepcopy(PUBLIC), ((1, 1), (2, 2)))
        manager = AgentManager()
        for agent in agents:
            manager.register_agent(agent)

        for step in (1, 2):
            factory.begin_training_step({"step": step, "entities": {}})
            actions = manager.collect_actions_from_agents({
                i: observation(i, step=step, peers=(3 - i,)) for i in (1, 2)
            })
            for agent, action in zip(agents, actions, strict=True):
                agent.record_step(
                    observation(agent.entity_id, step=step + 1, peers=(3 - agent.entity_id,)),
                    action, 1.0, {"done": False},
                )
            self.assertEqual(policy.observe.call_count, (step - 1) * 2)
            factory.finish_training_step({"step": step + 1, "entities": {}})

        transitions = [call.args[0] for call in policy.observe.call_args_list]
        self.assertEqual([item.agent_id for item in transitions], [1, 2, 1, 2])
        for index, transition in enumerate(transitions):
            global_state, next_global_state = states[index // 2]
            np.testing.assert_array_equal(transition.global_state, global_state)
            np.testing.assert_array_equal(transition.next_global_state, next_global_state)
        self.assertEqual(policy.finish_environment_step.call_count, 2)


if __name__ == "__main__":
    unittest.main()
