from dataclasses import replace
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from blue_defense import BlueDefenseConfig, BlueDefenseController, InterceptorAssignment
from envengine.sdk.writer import WriteConfig, init_writer
from test_blue_information import create_engine, place_sensor_targets, advance_until_detected


class BlueDefenseControllerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.writer = init_writer(WriteConfig(
            enable_config=False, enable_state=False, enable_event=False, enable_ai_action=False,
            output_dir=str(ROOT / ".blue_validation/controller"), verbose=False,
        ))
        cls.engine = create_engine()
        place_sensor_targets(cls.engine)
        advance_until_detected(cls.engine)
        factory = cls.engine.simulator_factory
        commander = factory.get_simulators_by_type(35000)[0]
        commander.sim_time = cls.engine.sim_time
        cls.observation = commander._build_blue_observation()

    @classmethod
    def tearDownClass(cls):
        cls.writer.close()

    def test_b3_preserves_configured_decision_interval(self):
        controller = BlueDefenseController(BlueDefenseConfig(
            policy_name="b3_min_cost_assignment", min_cost_decision_interval_ms=5000, seed=42,
        ))
        first = controller.decide(self.observation)
        self.assertIsNotNone(first)
        self.assertTrue(first.assignments)
        self.assertIsNone(controller.decide(replace(self.observation, sim_time=self.engine.sim_time + 1000)))
        self.assertIsNotNone(controller.decide(replace(self.observation, sim_time=self.engine.sim_time + 5000)))

    def test_b7_releases_on_timed_decision_and_reset_discards_old_plan(self):
        controller = BlueDefenseController(BlueDefenseConfig(
            policy_name="b7_planned_nearest", planning_delay_ms=5000, seed=42,
        ))
        self.assertEqual(controller.decide(self.observation).assignments, ())
        self.assertEqual(controller.decide(replace(self.observation, sim_time=self.engine.sim_time + 4999)).assignments, ())
        released = controller.decide(replace(self.observation, sim_time=self.engine.sim_time + 5000))
        self.assertTrue(released.assignments)
        self.assertTrue(all(isinstance(item, InterceptorAssignment) for item in released.assignments))
        controller.reset()
        self.assertEqual(controller.decide(replace(self.observation, sim_time=self.engine.sim_time + 5000)).assignments, ())

    def test_b0_reset_preserves_random_stream_by_default(self):
        config = BlueDefenseConfig(policy_name="b0_fixed_ratio_random", seed=17)
        continuous = BlueDefenseController(config)
        reset = BlueDefenseController(config)
        self.assertEqual(continuous.decide(self.observation), reset.decide(self.observation))
        reset.reset()
        self.assertEqual(continuous.decide(self.observation), reset.decide(self.observation))

    def test_b0_explicit_reseed_reproduces_decision(self):
        controller = BlueDefenseController(BlueDefenseConfig(
            policy_name="b0_fixed_ratio_random", seed=17, reset_rng_on_episode=True,
        ))
        first = controller.decide(self.observation)
        controller.reset()
        self.assertEqual(first, controller.decide(self.observation))

    def test_real_commander_uses_injected_controller_on_update(self):
        engine = create_engine("b7_planned_nearest")
        factory = engine.simulator_factory
        commander = factory.get_simulators_by_type(35000)[0]
        self.assertEqual(commander.defense_controller.name, "b7_planned_nearest")
        place_sensor_targets(engine)
        advance_until_detected(engine)
        controller = commander.defense_controller
        factory.blue_information.reset()
        commander.sim_time = engine.sim_time
        commander.update()
        self.assertIs(commander.defense_controller, controller)
        self.assertEqual(commander._build_blue_observation().targets, ())

    def test_real_launch_boundary_rejects_target_without_record(self):
        engine = create_engine()
        factory = engine.simulator_factory
        commander = factory.get_simulators_by_type(35000)[0]
        interceptor = factory.get_simulators_by_type(24000)[0]
        track = self.observation.targets[0]
        assignment = InterceptorAssignment(
            interceptor_id=interceptor.entity_ext.entity.id, target_id=track.target_id,
            target_pos_ecf=track.pos_ecf, target_vel_ecf=track.vel_ecf,
        )
        commander._execute_immediate_assignments([assignment])
        factory.process_commands()
        self.assertEqual(interceptor.launched, -1)
        self.assertEqual(commander.launched_list, {})


if __name__ == "__main__":
    unittest.main()
