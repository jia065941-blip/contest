import hashlib
import json
import math
from collections import Counter
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from envengine.sdk.base_struct.profile.profile import Profile
from scenarios import load_scenario
from scenarios.grid_maps.coordinates import lla_to_ecef


class Launch20ScenarioLoadingTests(unittest.TestCase):
    def test_blue_coordinates_and_attached_positions_are_consistent(self):
        for path in sorted((ROOT / 'scenarios/cases/launch20').glob('*/*/scenario.json')):
            raw = json.loads(path.read_text(encoding='utf-8'))
            entities = {row['entity']['id']: row['entity'] for row in raw['imagineProfile']['entityList']}
            for entity in entities.values():
                if entity['entityType'] not in (9400, 9500, 9600, 44000, 24000):
                    continue
                with self.subTest(map=path.parent.name, entity=entity['id']):
                    lla = entity['lla']
                    expected = lla_to_ecef(lla['x'], lla['y'], lla['z'])
                    actual = [entity['posEcf'][key] for key in ('x', 'y', 'z')]
                    self.assertLess(math.dist(actual, expected), 1e-5)
                    if entity['parentId'] != -1:
                        parent = entities[entity['parentId']]
                        self.assertEqual(entity['lla'], parent['lla'])
                        self.assertEqual(entity['posEcf'], parent['posEcf'])

    def test_tier_inventory_and_attack_agent_ratios(self):
        case_root = ROOT / 'scenarios/cases/launch20'
        manifest = json.loads((case_root / 'manifest.json').read_text(encoding='utf-8'))
        expected = {'easy': (78, 41), 'medium': (146, 64), 'hard': (348, 114)}
        for case in manifest['cases']:
            with self.subTest(map=case['id']):
                path = case_root / case['scenario']
                raw = json.loads(path.read_text(encoding='utf-8'))
                counts = Counter(item['entity']['entityType'] for item in raw['imagineProfile']['entityList'])
                interceptors, attackers = expected[case['difficulty']]
                self.assertEqual(counts[24000], interceptors)
                self.assertEqual(counts[21000] + counts[21001], attackers)
                info = json.loads(path.with_name('case_info.json').read_text(encoding='utf-8'))
                self.assertEqual(info['balance_design']['non_scavenger_agents'], attackers)
                self.assertAlmostEqual(info['balance_design']['interceptors_per_attack_agent_after'],
                                       interceptors / attackers)

    def test_all_scenarios_load_with_empty_communication_dictionaries(self):
        case_root = ROOT / 'scenarios/cases/launch20'
        manifest = json.loads((case_root / 'manifest.json').read_text(encoding='utf-8'))
        expected_ids = {f'E{i:02}' for i in range(1, 7)} | {f'M{i:02}' for i in range(1, 7)} | {
            f'H{i:02}' for i in range(1, 9)}
        self.assertEqual({case['id'] for case in manifest['cases']}, expected_ids)
        self.assertEqual(len(manifest['cases']), 20)
        for case in manifest['cases']:
            with self.subTest(map=case['id']):
                path = case_root / case['scenario']
                bundle = load_scenario(path)
                self.assertEqual(bundle.reward_policy.scenario_id, case['id'])
                raw = json.loads(path.read_text(encoding='utf-8'))
                profile = Profile.from_dict(raw)
                self.assertEqual(len(profile.imagineProfile.entityList), len(raw['imagineProfile']['entityList']))
                for item in profile.imagineProfile.entityList:
                    self.assertIsInstance(item.entity.commRangeInfo, dict)
                    self.assertEqual(item.entity.commRangeInfo, {})
                for name, expected_hash in case['files_sha256'].items():
                    content = path.with_name(name).read_bytes()
                    hashes = {hashlib.sha256(content).hexdigest()}
                    if name.endswith('.json'):
                        normalized = content.replace(b'\r\n', b'\n')
                        hashes.add(hashlib.sha256(normalized).hexdigest())
                        hashes.add(hashlib.sha256(normalized.replace(b'\n', b'\r\n')).hexdigest())
                    self.assertIn(expected_hash, hashes, name)


if __name__ == '__main__':
    unittest.main()
