"""Lifecycle checks for per-entity decisions and deployment-complete launch."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import patch

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from envengine.engine.engine import Engine  # noqa: E402
from envengine.environment.training_env import TrainingEnv  # noqa: E402
from envengine.simulator.simulator_factory import SimulatorFactory  # noqa: E402
from main import read_profile, resolve_deployment_constraints  # noqa: E402
from scenarios import load_scenario  # noqa: E402
from user_agents.red.deploy_agent import DeployAgent  # noqa: E402


class AgentLifecycleTests(unittest.TestCase):
    def _deployment_test_env(self, entity_specs):
        polygon = [[[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]]
        red_area = SimpleNamespace(coordinates=polygon, coordinatesHM=polygon)
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(redArea=red_area))
        simulators = {
            entity_id: SimpleNamespace(
                entity_ext=SimpleNamespace(
                    entity=SimpleNamespace(id=entity_id, entityType=entity_type)
                )
            )
            for entity_id, entity_type in entity_specs
        }

        class Factory:
            def __init__(self):
                self.positions = []
                self.speeds = []
                self.start_count = 0

            def get_simulator_by_id(self, entity_id):
                return simulators.get(entity_id)

            def get_simulators_by_type(self, entity_type):
                return [
                    simulator
                    for simulator in simulators.values()
                    if simulator.entity_ext.entity.entityType == entity_type
                ]

            def modify_simulator_position(self, entity_id, lla):
                self.positions.append((entity_id, lla))

            def modify_simulator_speed(self, entity_id, speed):
                self.speeds.append((entity_id, speed))

            def start_red_missions(self):
                self.start_count += 1

        factory = Factory()
        env = object.__new__(TrainingEnv)
        env.engine = SimpleNamespace(profile=profile, simulator_factory=factory)
        env.speed_distributor = SimpleNamespace(get_speed=lambda _lon: 123.0)
        env.current_round = 1
        env.render_mode = "none"
        env.renderer = None
        return env, factory

    def test_launch20_metadata_matches_engine_deployment_contract(self):
        bundle = load_scenario("launch20/easy/E01")
        profile = read_profile(str(bundle.path))

        coordinates, coordinates_hm, altitude = resolve_deployment_constraints(
            profile,
            bundle.deployment_area,
            deployment_plan=None,
        )

        self.assertEqual(coordinates, bundle.deployment_area["coordinates"])
        self.assertEqual(coordinates_hm, bundle.deployment_area["coordinatesHM"])
        self.assertEqual(altitude, 3000.0)

    def test_default_deploy_agent_ignores_red_support_assets(self):
        polygon = [[[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]]
        agent = DeployAgent(-1, -1, {}, polygon, polygon)
        agent.set_observation({
            "entities": {
                101: {"type": 21000, "position": {"alt": 3000.0}},
                158: {"type": 9202, "position": {"alt": 500000.0}},
            }
        })

        with patch("user_agents.red.deploy_agent.time.sleep"):
            deployment = agent.get_action()
            completion = agent.get_action()

        self.assertEqual(deployment.shape, (1, 5))
        self.assertEqual(int(deployment[0, 1]), 101)
        self.assertEqual(int(completion[0, 0]), 1)

    def test_deployment_completion_rejects_missing_platforms_before_mutation(self):
        env, factory = self._deployment_test_env(((101, 21000), (102, 21001)))
        env._generate_actions_from_deploy_agent = lambda: np.array(
            [[0, 101, 0.5, 0.5, 3000.0], [1, -1, 0, 0, 0]],
            dtype=np.float64,
        )

        with patch("envengine.environment.training_env.write_ai_action") as writer:
            with self.assertRaisesRegex(ValueError, "缺少 1 个"):
                TrainingEnv.red_model_deploy(env)

        self.assertEqual(factory.positions, [])
        self.assertEqual(factory.start_count, 0)
        writer.assert_not_called()

    def test_deployment_rejects_duplicate_platform_before_mutation(self):
        env, factory = self._deployment_test_env(((101, 21000),))
        env._generate_actions_from_deploy_agent = lambda: np.array(
            [[0, 101, 0.4, 0.4, 3000.0], [0, 101, 0.5, 0.5, 3000.0]],
            dtype=np.float64,
        )

        with patch("envengine.environment.training_env.write_ai_action") as writer:
            with self.assertRaisesRegex(ValueError, "重复部署"):
                TrainingEnv.red_model_deploy(env)

        self.assertEqual(factory.positions, [])
        self.assertEqual(factory.start_count, 0)
        writer.assert_not_called()

    def test_deployment_rejects_nan_before_mutation(self):
        env, factory = self._deployment_test_env(((101, 21000),))
        env._generate_actions_from_deploy_agent = lambda: np.array(
            [[0, 101, np.nan, 0.5, 3000.0]], dtype=np.float64
        )

        with patch("envengine.environment.training_env.write_ai_action") as writer:
            with self.assertRaisesRegex(ValueError, "NaN"):
                TrainingEnv.red_model_deploy(env)

        self.assertEqual(factory.positions, [])
        self.assertEqual(factory.start_count, 0)
        writer.assert_not_called()

    def test_reset_resets_engine_and_registered_agents_once_per_round(self):
        env = object.__new__(TrainingEnv)
        events = []
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(
            redArea=SimpleNamespace(), mapArea=SimpleNamespace(),
        ))
        env.engine = SimpleNamespace(profile=profile, reset=lambda: events.append("engine"))
        env.agent_manager = SimpleNamespace(reset_all=lambda: events.append("agents"))
        env.current_step = 9
        env.current_round = 0
        env.render_mode = "none"
        env.renderer = None
        env._get_observation = lambda: {"step": 0, "entities": {}}

        with patch("envengine.environment.training_env.write_config"), patch(
            "envengine.environment.training_env.write_state"
        ):
            TrainingEnv.reset(env)
            TrainingEnv.reset(env)

        self.assertEqual(events, ["engine", "agents", "engine", "agents"])
        self.assertEqual(env.current_round, 2)
        self.assertEqual(env.current_step, 0)
        self.assertIsNone(env._last_actions)

    def test_observations_are_set_for_all_agents_before_any_action(self):
        env = object.__new__(TrainingEnv)
        events = []

        class Agent:
            def __init__(self, agent_id):
                self.agent_id = self.entity_id = agent_id

            def get_entity_id(self):
                return self.entity_id

            def set_observation(self, observation):
                events.append(("set", self.agent_id))
                self.observation = observation

            def get_action(self):
                events.append(("get", self.agent_id))
                return np.array([[2, self.entity_id, self.observation["self"]["position"]["lon"], 1]])

        from envengine.agent_manager import AgentManager

        env.agent_manager = AgentManager()
        for agent_id in (1, 2):
            env.agent_manager.register_agent(Agent(agent_id))
        env.engine = SimpleNamespace(
            refresh_red_communications=lambda: events.append(("refresh",)),
            simulator_factory=SimpleNamespace(is_using_satellite=lambda: False),
        )
        env._get_observation = lambda: {"step": 0, "entities": {
            i: {"health": 1, "isVisible": True, "position": {"lon": i + 0.5}}
            for i in (1, 2)
        }}

        actions = TrainingEnv._generate_actions_from_agents(env)

        self.assertEqual(events, [("refresh",), ("set", 1), ("set", 2), ("get", 1), ("get", 2)])
        self.assertEqual([item["target"]["x"] for item in actions], [1.5, 2.5])

    def test_feedback_is_isolated_between_agents_and_environment(self):
        from envengine.agent_manager import AgentManager

        env = object.__new__(TrainingEnv)
        received = []

        def feedback(observation, action, reward, info):
            received.append((observation["entity_id"], observation["self"]["health"],
                             action["target_id"], reward, info["done"]))
            observation["self"]["health"] = 0
            action["target_id"] = -1
            info["done"] = True

        env.agent_manager = AgentManager()
        for i in (1, 2):
            env.agent_manager.register_agent(SimpleNamespace(
                agent_id=i, entity_id=i, get_entity_id=lambda i=i: i, record_step=feedback,
            ))
        commands = [{"executor_id": i, "target_id": 100 + i} for i in (1, 2)]
        observation = {"step": 1, "entities": {
            i: {"health": 100, "isVisible": True} for i in (1, 2)
        }}
        env.engine = SimpleNamespace(step=lambda _: None)
        env.current_step = 0
        env.current_round = 1
        env.max_steps = 10
        env.render_mode = "none"
        env.renderer = None
        env._generate_actions_from_agents = lambda: commands
        env._get_observation = lambda: observation
        env._compute_reward = lambda: {1: 2.5, 2: 3.5}
        env.get_is_done = lambda: False

        with patch("envengine.environment.training_env.write_ai_action"), patch(
            "envengine.environment.training_env.write_state"
        ), patch("envengine.environment.training_env.CommandAdapter.common_adapter", return_value=[]):
            _, _, _, info = TrainingEnv.step(env)

        self.assertEqual(received, [(1, 100, 101, 2.5, False), (2, 100, 102, 3.5, False)])
        self.assertFalse(info["done"])
        self.assertEqual([item["target_id"] for item in commands], [101, 102])
        self.assertEqual([item["health"] for item in observation["entities"].values()], [100, 100])

    def test_deployment_validates_position_and_starts_red_models_once(self):
        env = object.__new__(TrainingEnv)
        polygon = [[[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]]
        red_area = SimpleNamespace(coordinates=polygon, coordinatesHM=polygon)
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(redArea=red_area))
        entity = SimpleNamespace(id=101, entityType=21000)
        simulator = SimpleNamespace(entity_ext=SimpleNamespace(entity=entity))

        class Factory:
            def __init__(self):
                self.positions = []
                self.speeds = []
                self.start_count = 0

            def get_simulator_by_id(self, entity_id):
                return simulator if entity_id == 101 else None

            def get_simulators_by_type(self, entity_type):
                return [simulator] if entity_type == 21000 else []

            def modify_simulator_position(self, entity_id, lla):
                self.positions.append((entity_id, lla))

            def modify_simulator_speed(self, entity_id, speed):
                self.speeds.append((entity_id, speed))

            def start_red_missions(self):
                self.start_count += 1

        factory = Factory()
        env.engine = SimpleNamespace(profile=profile, simulator_factory=factory)
        env.speed_distributor = SimpleNamespace(get_speed=lambda _lon: 123.0)
        env.current_round = 1
        env.render_mode = "none"
        env.renderer = None
        batches = iter(
            (
                np.array([[0, 101, 0.5, 0.5, 3000.0]], dtype=np.float64),
                np.array([[1, -1, 0, 0, 0]], dtype=np.float64),
            )
        )
        env._generate_actions_from_deploy_agent = lambda: next(batches)

        with patch("envengine.environment.training_env.write_ai_action"):
            TrainingEnv.red_model_deploy(env)

        self.assertEqual(factory.start_count, 1)
        self.assertEqual(factory.positions[0][0], 101)
        self.assertEqual(factory.speeds, [(101, 123.0)])

    def test_out_of_bounds_deployment_fails_before_launch(self):
        env = object.__new__(TrainingEnv)
        polygon = [[[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]]
        red_area = SimpleNamespace(coordinates=polygon, coordinatesHM=polygon)
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(redArea=red_area))
        entity = SimpleNamespace(id=101, entityType=21002)
        simulator = SimpleNamespace(entity_ext=SimpleNamespace(entity=entity))
        factory = SimpleNamespace(
            get_simulator_by_id=lambda _entity_id: simulator,
            get_simulators_by_type=lambda entity_type: (
                [simulator] if entity_type == 21002 else []
            ),
            modify_simulator_position=lambda *_args: self.fail("invalid move applied"),
            modify_simulator_speed=lambda *_args: self.fail("invalid speed applied"),
            start_red_missions=lambda: self.fail("invalid deployment launched"),
        )
        env.engine = SimpleNamespace(profile=profile, simulator_factory=factory)
        env.speed_distributor = SimpleNamespace(get_speed=lambda _lon: 0.0)
        env.current_round = 1
        env.render_mode = "none"
        env.renderer = None
        env._generate_actions_from_deploy_agent = lambda: np.array(
            [[0, 101, 2.0, 0.5, 3000.0]], dtype=np.float64
        )

        with patch("envengine.environment.training_env.write_ai_action"):
            with self.assertRaisesRegex(ValueError, "超出允许区域"):
                TrainingEnv.red_model_deploy(env)

    def test_wrong_deployment_altitude_fails_before_position_change(self):
        env = object.__new__(TrainingEnv)
        polygon = [[[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]]
        red_area = SimpleNamespace(coordinates=polygon, coordinatesHM=polygon)
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(redArea=red_area))
        entity = SimpleNamespace(id=101, entityType=21000)
        simulator = SimpleNamespace(entity_ext=SimpleNamespace(entity=entity))
        factory = SimpleNamespace(
            get_simulator_by_id=lambda _entity_id: simulator,
            get_simulators_by_type=lambda entity_type: (
                [simulator] if entity_type == 21000 else []
            ),
            modify_simulator_position=lambda *_args: self.fail("invalid move applied"),
            modify_simulator_speed=lambda *_args: self.fail("invalid speed applied"),
            start_red_missions=lambda: self.fail("invalid deployment launched"),
        )
        env.engine = SimpleNamespace(profile=profile, simulator_factory=factory)
        env.speed_distributor = SimpleNamespace(get_speed=lambda _lon: 0.0)
        env.current_round = 1
        env.render_mode = "none"
        env.renderer = None
        env._deployment_launch_altitude = 3000.0
        env._generate_actions_from_deploy_agent = lambda: np.array(
            [[0, 101, 0.5, 0.5, 2000.0]], dtype=np.float64
        )

        with patch("envengine.environment.training_env.write_ai_action") as writer:
            with self.assertRaisesRegex(ValueError, "部署高度"):
                TrainingEnv.red_model_deploy(env)
        writer.assert_not_called()

    def test_engine_reset_updates_simulator_clock_before_initialization(self):
        order = []
        factory = SimpleNamespace(
            update_sim_time=lambda value: order.append(("clock", value)),
            reset_all=lambda: order.append(("reset", None)),
        )
        imagine = SimpleNamespace(simStep=1000, simEndLogicTime=3000, simTime=250)
        engine = object.__new__(Engine)
        engine.profile = SimpleNamespace(imagineProfile=imagine)
        engine.simulator_factory = factory
        engine.speed_multiplier = 0

        Engine.reset(engine)

        self.assertEqual(order, [("clock", 250), ("reset", None)])
        self.assertEqual(engine.sim_time, 250)

    def test_factory_starts_each_red_model_once(self):
        simulations = {
            entity_type: [SimpleNamespace(start_count=0)]
            for entity_type in (21000, 21001, 21002)
        }
        for items in simulations.values():
            items[0].start_mission = lambda item=items[0]: setattr(
                item, "start_count", item.start_count + 1
            )
        factory = object.__new__(SimulatorFactory)
        factory.get_simulators_by_type = lambda entity_type: simulations[entity_type]

        SimulatorFactory.start_red_missions(factory)

        self.assertEqual(
            [simulations[entity_type][0].start_count for entity_type in simulations],
            [1, 1, 1],
        )


if __name__ == "__main__":
    unittest.main()
