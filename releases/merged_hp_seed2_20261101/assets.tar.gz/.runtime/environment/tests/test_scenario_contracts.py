"""Validate packaged scenes against their own current manifests and metadata.

Launch20 is the default continuous-deployment set. Final20 remains an optional
grid-deployment set; its logical layout is a geometry design artifact, while
scenario.json and case_info.json define the effective runtime inventory/health.
"""

from __future__ import annotations

import hashlib
import json
import math
import statistics
import unittest
from collections import Counter
from pathlib import Path

from scenarios.grid_maps.coordinates import board_to_lla
from scenarios.grid_maps.deployment import compile_actions, validate_plan


CASES = Path(__file__).resolve().parents[1] / "scenarios" / "cases"
RED_TYPES = {"high": 21000, "medium": 21001, "low": 21002}
BLUE_TYPES = {"target": 9400, "site": 9600, "ship": 9500}
LAYOUT_TYPES = {"mother": 9400, "watch": 9600, "hidden": 9500}
EXPECTED_CASES = {"easy": 6, "medium": 6, "hard": 8}
RADAR_TYPE = 44000
INTERCEPTOR_TYPE = 24000


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def checksum(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rows(scenario):
    return [item["entity"] for item in scenario["imagineProfile"]["entityList"]]


def rectangle_contains(coordinates, lla):
    # Both published deployment sets use a single axis-aligned rectangle.
    points = coordinates[0]
    return (min(p[0] for p in points) <= lla["x"] <= max(p[0] for p in points)
            and min(p[1] for p in points) <= lla["y"] <= max(p[1] for p in points))


class ScenarioContractsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = []
        for package in ("launch20", "final20"):
            for path in sorted((CASES / package).glob("*/*/scenario.json")):
                cls.cases.append((package, path, load(path), load(path.with_name("case_info.json"))))

    def test_case_distribution_and_manifest_completeness(self):
        for package in ("launch20", "final20"):
            folder = CASES / package
            manifest = load(folder / "manifest.json")
            entries = manifest["cases" if package == "launch20" else "maps"]
            declared = set()
            for item in entries:
                case_id = item["id" if package == "launch20" else "map"]
                difficulty = item["difficulty" if package == "launch20" else "tier"]
                self.assertNotIn((difficulty, case_id), declared)
                declared.add((difficulty, case_id))
            actual = set()
            for difficulty, count in EXPECTED_CASES.items():
                prefix = {"easy": "E", "medium": "M", "hard": "H"}[difficulty]
                names = sorted(p.name for p in (folder / difficulty).iterdir() if p.is_dir())
                self.assertEqual([f"{prefix}{index:02d}" for index in range(1, count + 1)], names)
                actual.update((difficulty, name) for name in names)
            self.assertEqual(actual, declared)
            self.assertEqual(20, len(declared))

    def test_manifest_hashes_and_metadata_identity(self):
        for package in ("launch20", "final20"):
            manifest = load(CASES / package / "manifest.json")
            entries = manifest["cases" if package == "launch20" else "maps"]
            signatures = set()
            for entry in entries:
                case_id = entry["id" if package == "launch20" else "map"]
                difficulty = entry["difficulty" if package == "launch20" else "tier"]
                with self.subTest(package=package, case=case_id):
                    folder = CASES / package / difficulty / case_id
                    path = folder / "scenario.json"
                    info = load(folder / "case_info.json")
                    self.assertEqual(case_id, info["scenario_id"])
                    self.assertEqual(difficulty, info["difficulty"])
                    actual_hash = checksum(path)
                    self.assertEqual(info["scenario_sha256"], actual_hash)
                    self.assertNotIn(actual_hash, signatures)
                    signatures.add(actual_hash)
                    if package == "launch20":
                        self.assertEqual(path, CASES / package / entry["scenario"])
                        self.assertEqual({"scenario.json", "case_info.json", "deployment_area.json", "map_info.png"}, set(entry["files_sha256"]))
                        for filename, expected_hash in entry["files_sha256"].items():
                            self.assertEqual(expected_hash, checksum(folder / filename), filename)
                    else:
                        self.assertEqual(entry["scenario_sha256"], actual_hash)
                        for filename in ("map_info.png", "map_public.png", "map_engine_check.png"):
                            self.assertTrue((folder / filename).is_file(), filename)
            self.assertEqual(20, len(signatures))
        for filename in ("final_20_overview.png", "overview_easy.png", "overview_medium.png", "overview_hard.png"):
            self.assertTrue((CASES / "final20" / filename).is_file())

    def test_runtime_inventory_health_and_timing_match_metadata(self):
        for package, path, scenario, info in self.cases:
            with self.subTest(package=package, case=info["scenario_id"]):
                profile = scenario["imagineProfile"]
                entities = rows(scenario)
                by_id = {row["id"]: row for row in entities}
                counts = Counter(row["entityType"] for row in entities)
                self.assertEqual(len(entities), len(by_id))
                self.assertEqual(len(entities), info["entity_total"])
                self.assertEqual({kind: counts[kind_id] for kind, kind_id in BLUE_TYPES.items()}, info["root_counts"])
                self.assertEqual({kind: counts[kind_id] for kind, kind_id in RED_TYPES.items()}, info["red_missile_counts"])
                self.assertEqual(sum(info["root_counts"].values()), info["blue_root_total"])
                self.assertEqual(counts[RADAR_TYPE], info["radar_total"])
                self.assertEqual(counts[INTERCEPTOR_TYPE], info["interceptor_total"])
                self.assertGreater(info["max_steps"], 0)
                self.assertEqual(info["max_steps"] * profile["simStep"], profile["simEndLogicTime"])
                self.assertEqual(info["map_area"], profile["mapArea"])
                root_ids = {row["id"] for row in entities if row["entityType"] in BLUE_TYPES.values()}
                self.assertEqual(root_ids, {root["id"] for root in info["roots"]})
                for root in info["roots"]:
                    entity = by_id[root["id"]]
                    self.assertEqual(BLUE_TYPES[root["kind"]], entity["entityType"])
                    self.assertAlmostEqual(root["lon"], entity["lla"]["x"])
                    self.assertAlmostEqual(root["lat"], entity["lla"]["y"])
                    self.assertAlmostEqual(root["hp"], entity["survivePoints"])
                    self.assertEqual("hidden" if root["kind"] == "ship" else "public", root["initial_information"])

    def test_entity_graph_objectives_and_radar_contract(self):
        for package, path, scenario, info in self.cases:
            with self.subTest(package=package, case=info["scenario_id"]):
                profile = scenario["imagineProfile"]
                entities = rows(scenario)
                by_id = {row["id"]: row for row in entities}
                area = profile["mapArea"]
                for entity in entities:
                    parent = entity.get("parentId", -1)
                    if parent != -1:
                        self.assertIn(parent, by_id)
                        self.assertIn(entity["id"], by_id[parent].get("childrenId", ()))
                    children = entity.get("childrenId", ())
                    self.assertEqual(len(children), len(set(children)))
                    for child in children:
                        self.assertIn(child, by_id)
                        self.assertEqual(entity["id"], by_id[child].get("parentId"))
                    if entity["entityType"] in BLUE_TYPES.values():
                        self.assertLessEqual(area["lonMin"], entity["lla"]["x"])
                        self.assertGreaterEqual(area["lonMax"], entity["lla"]["x"])
                        self.assertLessEqual(area["latMin"], entity["lla"]["y"])
                        self.assertGreaterEqual(area["latMax"], entity["lla"]["y"])
                for item in profile["entityList"]:
                    if item["entity"]["entityType"] == RADAR_TYPE:
                        self.assertNotIn("distance", json.loads(item["external"])["raderExternal"])
                target_ids = {row["id"] for row in entities if row["entityType"] == BLUE_TYPES["target"]}
                site_ids = {row["id"] for row in entities if row["entityType"] == BLUE_TYPES["site"]}
                ship_ids = {row["id"] for row in entities if row["entityType"] == BLUE_TYPES["ship"]}
                self.assertEqual(target_ids | site_ids | ship_ids, set(info["objective_ids"]))
                self.assertEqual(target_ids | site_ids, set(info["public_objective_ids"]))
                self.assertEqual(ship_ids, set(info["hidden_objective_ids"]))
                self.assertEqual(len(site_ids), info["radar_total"])
                for root_id in site_ids | ship_ids:
                    radar_ids = [child for child in by_id[root_id].get("childrenId", ()) if by_id[child]["entityType"] == RADAR_TYPE]
                    self.assertEqual(1 if root_id in site_ids else 0, len(radar_ids))
                    for radar_id in radar_ids:
                        self.assertEqual(by_id[root_id]["lla"], by_id[radar_id]["lla"])
                assigned = {int(key): value for key, value in info["interceptor_counts"].items()}
                self.assertEqual(site_ids | ship_ids, set(assigned))
                self.assertEqual(info["interceptor_total"], sum(assigned.values()))
                for root_id, amount in assigned.items():
                    root = by_id[root_id]
                    children = [child for child in root.get("childrenId", ()) if by_id[child]["entityType"] == INTERCEPTOR_TYPE]
                    self.assertEqual(amount, len(children))
                    self.assertEqual(amount, next(r["interceptors"] for r in info["roots"] if r["id"] == root_id))
                    for child_id in children:
                        self.assertEqual(root["lla"], by_id[child_id]["lla"])

    def test_launch20_free_deployment_contract(self):
        manifest = load(CASES / "launch20" / "manifest.json")
        self.assertTrue(manifest["all_units_depart_at_start"])
        self.assertFalse(manifest["grid_required"])
        for package, path, scenario, info in self.cases:
            if package != "launch20":
                continue
            with self.subTest(case=info["scenario_id"]):
                profile = scenario["imagineProfile"]
                deployment = load(path.with_name("deployment_area.json"))
                self.assertEqual(info["scenario_id"], deployment["map_id"])
                self.assertEqual("free", deployment["mode"])
                self.assertTrue(deployment["all_units_depart_at_start"])
                self.assertFalse(deployment["grid_required"])
                self.assertEqual(manifest["max_steps"], info["max_steps"])
                self.assertEqual(manifest["geometry_revision"], info["topology_model"])
                self.assertEqual(info["satelliteMaxUseCount"], profile["satelliteMaxUseCount"])
                self._assert_deployment_positions(profile, deployment, info)
                area = profile["mapArea"]
                for x, y in info["public_engagement_polygon"]:
                    self.assertTrue(area["lonMin"] <= x <= area["lonMax"])
                    self.assertTrue(area["latMin"] <= y <= area["latMax"])

    def _assert_deployment_positions(self, profile, deployment, info):
        for field in ("coordinates", "coordinatesHM"):
            self.assertEqual(profile["redArea"][field], deployment[field])
            self.assertEqual(1, len(deployment[field]))
            points = deployment[field][0]
            self.assertEqual(4, len(points))
            self.assertTrue(all(math.isfinite(axis) for point in points for axis in point))
            west, east = min(p[0] for p in points), max(p[0] for p in points)
            south, north = min(p[1] for p in points), max(p[1] for p in points)
            self.assertLess(west, east)
            self.assertLess(south, north)
            self.assertEqual({(west, south), (west, north), (east, south), (east, north)}, set(map(tuple, points)))
        self.assertEqual(deployment["coordinates"], deployment["coordinatesHM"])
        self.assertEqual(info["launch_altitude_external_m"], deployment["launch_altitude_external_m"])
        for item in profile["entityList"]:
            entity = item["entity"]
            if entity["entityType"] in RED_TYPES.values():
                self.assertTrue(rectangle_contains(deployment["coordinates"], entity["lla"]))
                self.assertEqual(deployment["launch_altitude_external_m"], entity["lla"]["z"])

    def test_final20_budget_matches_manifest_layout_and_runtime(self):
        manifest = {entry["map"]: entry for entry in load(CASES / "final20" / "manifest.json")["maps"]}
        for package, path, scenario, info in self.cases:
            if package != "final20":
                continue
            with self.subTest(case=info["scenario_id"]):
                layout = load(path.with_name("layout.design.json"))
                budget = layout["budget"]
                entry = manifest[info["scenario_id"]]
                self.assertEqual(info["scenario_id"], layout["map_id"])
                self.assertEqual(info["map_area"], layout["map_area"])
                self.assertEqual(info["logical_map_size"], layout["size"])
                self.assertEqual([info["red_missile_counts"][kind] for kind in RED_TYPES], budget["red"])
                self.assertEqual([info["root_counts"][kind] for kind in BLUE_TYPES], budget["blue"])
                self.assertEqual(info["root_counts"]["target"], entry["mothers"])
                self.assertEqual(info["interceptor_total"], budget["swarm"])
                self.assertEqual(info["interceptor_total"], entry["stock"])
                self.assertEqual(sum(info["red_missile_counts"].values()), entry["red"])
                self.assertEqual(entry["red"], budget["red_total"])
                self.assertEqual(info["blue_root_total"], budget["blue_total"])
                self.assertEqual(info["entity_total"], entry["entities"])
                self.assertEqual(entry["entities"], budget["total_entities"])
                actual_health = sum(row["survivePoints"] for row in rows(scenario) if row["entityType"] in BLUE_TYPES.values())
                self.assertAlmostEqual(actual_health, info["blue_root_health_total"])
                self.assertAlmostEqual(actual_health, budget["total_hp"])
                self.assertEqual(info["red_nominal_damage_total"], budget["nominal_damage"])
                self.assertAlmostEqual(actual_health / budget["nominal_damage"], info["blue_health_to_red_nominal_damage_ratio"])

    def test_final20_design_geometry_and_stock_match_runtime(self):
        signatures = set()
        for package, path, scenario, info in self.cases:
            if package != "final20":
                continue
            with self.subTest(case=info["scenario_id"]):
                layout = load(path.with_name("layout.design.json"))
                by_id = {row["id"]: row for row in rows(scenario)}
                self.assertEqual(set(info["objective_ids"]), {root["source_id"] for root in layout["roots"]})
                signature = []
                for root in layout["roots"]:
                    entity = by_id[root["source_id"]]
                    self.assertEqual(LAYOUT_TYPES[root["kind"]], entity["entityType"])
                    self.assertAlmostEqual(root["x_norm"] * layout["size"][0], root["x"])
                    self.assertAlmostEqual(root["y_norm"] * layout["size"][1], root["y"])
                    expected = board_to_lla(root["x"], root["y"], *layout["size"], info["map_area"])
                    self.assertAlmostEqual(expected["x"], entity["lla"]["x"])
                    self.assertAlmostEqual(expected["y"], entity["lla"]["y"])
                    self.assertEqual(info["interceptor_counts"].get(str(root["source_id"]), 0), root["swarm_stock"])
                    signature.append((entity["entityType"], root["x_norm"], root["y_norm"]))
                signature = tuple(sorted(signature))
                self.assertNotIn(signature, signatures)
                signatures.add(signature)
        self.assertEqual(20, len(signatures))

    def test_final20_grid_plan_matches_inventory_and_deployment(self):
        for package, path, scenario, info in self.cases:
            if package != "final20":
                continue
            with self.subTest(case=info["scenario_id"]):
                profile = scenario["imagineProfile"]
                grid = load(path.with_name("deployment_grid.json"))
                plan = load(path.with_name("deployment_plan.example.json"))
                self._assert_deployment_positions(profile, grid, info)
                self.assertEqual(info["scenario_id"], grid["map_id"])
                self.assertEqual((8, 4), (grid["rows"], grid["columns"]))
                expected = {kind_id: info["red_missile_counts"][kind] for kind, kind_id in RED_TYPES.items()}
                self.assertEqual({str(key): value for key, value in expected.items()}, grid["type_totals"])
                counts = validate_plan(plan, expected)
                combined = [0] * 32
                for matrix in counts.values():
                    cells = [value for row in matrix for value in row]
                    self.assertLessEqual(max(cells) - min(cells), 1)
                    combined = [old + new for old, new in zip(combined, cells)]
                self.assertLessEqual(max(combined) - min(combined), 1)
                observed = {row["id"]: {"type": row["entityType"], "position": {"alt": row["lla"]["z"]}}
                            for row in rows(scenario) if row["entityType"] in RED_TYPES.values()}
                actions = compile_actions(plan, observed, grid["coordinates"], grid["coordinatesHM"])
                self.assertEqual(set(observed), {action[1] for action in actions})
                self.assertEqual(len(actions), len({tuple(action[2:]) for action in actions}))
                current = {row["id"]: row["lla"] for row in rows(scenario)}
                for _, entity_id, x, y, z in actions:
                    self.assertAlmostEqual(x, current[entity_id]["x"])
                    self.assertAlmostEqual(y, current[entity_id]["y"])
                    self.assertAlmostEqual(z, current[entity_id]["z"])

    def test_final20_distribution_labels_match_declared_bands(self):
        labels = Counter()
        for package, path, scenario, info in self.cases:
            if package != "final20":
                continue
            with self.subTest(case=info["scenario_id"]):
                layout = load(path.with_name("layout.design.json"))
                bands = [{"public": 0, "swarm": 0} for _ in range(4)]
                for root in layout["roots"]:
                    index = min(3, int(root["y_norm"] * 4))
                    bands[index]["public"] += int(root["kind"] != "hidden")
                    bands[index]["swarm"] += root["swarm_stock"]
                self.assertEqual(bands, info["band_counts"])
                for field in ("public", "swarm"):
                    values = [band[field] for band in bands]
                    cv = statistics.pstdev(values) / statistics.mean(values)
                    self.assertAlmostEqual(cv, info["band_cv"][field])
                total_public = sum(band["public"] for band in bands)
                quotient, remainder = divmod(total_public, 4)
                balanced = [quotient + (index < remainder) for index in range(4)]
                minimum_cv = statistics.pstdev(balanced) / statistics.mean(balanced)
                limits = info["distribution_rule"]
                uniform = (info["band_cv"]["public"] <= max(limits["public_cv_limit"], minimum_cv) + 1e-12
                           and info["band_cv"]["swarm"] <= limits["stock_cv_limit"] + 1e-12)
                expected = "比较均匀" if uniform else "部分不均匀"
                self.assertEqual(expected, info["distribution"])
                self.assertEqual(expected, layout["distribution"])
                labels[expected] += 1
        self.assertEqual({"比较均匀": 8, "部分不均匀": 12}, dict(labels))


if __name__ == "__main__":
    unittest.main()
