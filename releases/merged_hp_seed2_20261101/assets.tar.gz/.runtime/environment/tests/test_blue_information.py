from dataclasses import FrozenInstanceError, replace
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from blue_defense import (
    BLUE_POLICY_CHOICES, BlueDefenseConfig, BlueDefenseController, BlueInformationStore,
    ScheduledInterceptorAssignment, build_blue_policy,
)
from envengine import Engine, Profile
from envengine.common import DamageC, DamageCmd, SimmerCommandType
from envengine.sdk.Util.UtilsPy import Vector3D
from envengine.sdk.base_struct.Basic import Vector3d
from envengine.sdk.base_struct.Message import Command
from envengine.sdk.writer import WriteConfig, init_writer


def create_engine(policy_name=BLUE_POLICY_CHOICES[0]):
    scenario = ROOT / "scenarios/cases/launch20/easy/E01/scenario.json"
    profile = Profile.from_dict(json.loads(scenario.read_text(encoding="utf-8")))
    engine = Engine(profile, speed_multiplier=0)
    engine.reset()
    factory = engine.simulator_factory
    if factory.get_simulator_count() != len(profile.imagineProfile.entityList):
        raise AssertionError("真实场景的实体没有完整初始化")
    factory.get_simulators_by_type(35000)[0].set_defense_controller(
        BlueDefenseController(BlueDefenseConfig(policy_name=policy_name, seed=42)),
    )
    return engine


def place_sensor_targets(engine):
    factory = engine.simulator_factory
    radars = factory.get_simulators_by_type(44000)
    units = [factory.get_simulators_by_type(entity_type)[0]
             for entity_type in (21000, 21001, 21002)]
    # 使用真实模型测试传感器附近的行为，不生成比赛成绩。
    for index, unit in enumerate(units):
        origin = radars[index].entity_ext.entity.lla
        unit.set_lla(Vector3d(origin.x + 0.02 + index * 0.003, origin.y, 100.0))
    factory.start_red_missions()
    return units


def advance_until_detected(engine):
    for _ in range(200):
        engine.step([])
        targets = engine.simulator_factory.blue_information.snapshot(engine.sim_time).targets
        if len(targets) >= 3 and len({track.source_id for track in targets}) >= 2:
            return
    raise AssertionError("真实雷达没有形成多个来源的三类红方记录")


class BlueInformationNativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.writer = init_writer(WriteConfig(
            enable_config=False, enable_state=False, enable_event=False, enable_ai_action=False,
            output_dir=str(ROOT / ".blue_validation/writer"), verbose=False,
        ))
        cls.engine = create_engine()
        cls.red_units = place_sensor_targets(cls.engine)
        advance_until_detected(cls.engine)
        cls.factory = cls.engine.simulator_factory
        cls.commander = cls.factory.get_simulators_by_type(35000)[0]
        cls.commander.sim_time = cls.engine.sim_time
        cls.observation = cls.commander._build_blue_observation()
        cls.records = tuple(record for radar in cls.factory.get_simulators_by_type(44000)
                            for record in radar.entity_ext.entity.detectInfo.values())
        cls.tracks = tuple(cls.commander._detect_info_to_threat_track(record)
                           for record in cls.records)

    @classmethod
    def tearDownClass(cls):
        cls.writer.close()

    def make_store(self):
        information = BlueInformationStore()
        information.receive_tracks(self.tracks, self.engine.sim_time)
        information.update_own_state(self.observation.interceptors, self.observation.assets,
                                     self.observation.launched_map)
        return information

    def test_empty_library_cannot_observe_existing_red_entities(self):
        self.assertEqual(BlueInformationStore().snapshot(self.engine.sim_time).targets, ())
        self.assertGreater(len(self.factory.get_simulators_by_type(21000)), 0)

    def test_prediction_and_expiry_use_recorded_time(self):
        information = self.make_store()
        track = max(self.tracks, key=lambda item: (item.detect_time, -item.source_id))
        predicted = information.get_track(track.target_id, track.detect_time + 1000)
        self.assertEqual(predicted.detect_time, track.detect_time)
        self.assertEqual(predicted.pos_ecf.x, track.pos_ecf.x + track.vel_ecf.x)
        self.assertIsNotNone(information.get_track(track.target_id, track.detect_time + 30_000))
        self.assertIsNone(information.get_track(track.target_id, track.detect_time + 30_001))

    def test_all_sources_merge_and_old_records_do_not_overwrite(self):
        information = BlueInformationStore()
        self.assertGreater(len({track.source_id for track in self.tracks}), 1)
        for track in sorted(self.tracks, key=lambda item: item.detect_time, reverse=True):
            information.receive_tracks([track], self.engine.sim_time)
        current = information.snapshot(self.engine.sim_time)
        self.assertEqual({track.target_id for track in current.targets},
                         {track.target_id for track in self.tracks})
        for track in current.targets:
            expected = max((item for item in self.tracks if item.target_id == track.target_id),
                           key=lambda item: (item.detect_time, -item.source_id))
            self.assertEqual((track.detect_time, track.source_id),
                             (expected.detect_time, expected.source_id))

    def test_radar_records_have_independent_coordinates(self):
        for record in self.records:
            entity = self.factory.get_simulator_by_id(record.entity_id).entity_ext.entity
            for record_field, entity_field in (("pos_ecf", "posEcf"), ("vel_ecf", "velEcf"), ("lla", "lla")):
                self.assertIsNot(getattr(record, record_field), getattr(entity, entity_field))

    def test_snapshot_is_read_only(self):
        observation = self.make_store().snapshot(self.engine.sim_time)
        with self.assertRaises(FrozenInstanceError):
            observation.sim_time = 0
        with self.assertRaises(TypeError):
            observation.launched_map[1] = ()
        self.assertIsInstance(observation.targets, tuple)

    def test_invalid_source_and_future_time_are_rejected(self):
        record = self.records[0]
        original_source = record.detect_from
        record.detect_from = self.red_units[0].entity_ext.entity.id
        try:
            with self.assertRaises(ValueError):
                self.commander._detect_info_to_threat_track(record)
        finally:
            record.detect_from = original_source
        with self.assertRaises(ValueError):
            self.make_store().receive_tracks(
                [replace(self.tracks[0], detect_time=self.engine.sim_time + 1)], self.engine.sim_time,
            )

    def test_hidden_destruction_does_not_remove_known_track(self):
        engine = create_engine()
        red_units = place_sensor_targets(engine)
        advance_until_detected(engine)
        factory = engine.simulator_factory
        commander = factory.get_simulators_by_type(35000)[0]
        commander.sim_time = engine.sim_time
        before = commander._build_blue_observation()
        track = next(item for item in before.targets if item.target_id == red_units[0].entity_ext.entity.id)
        factory._send_command_callback([Command(
            prevTriggerId=track.target_id, executorId=track.target_id,
            commandTypeId=SimmerCommandType.DAMAGE,
            commandAttributes=DamageC(DamageCmd(damagePoint=5000)).to_json(),
        )])
        factory.process_commands()
        self.assertEqual(red_units[0].entity_ext.entity.survivePoints, 0)
        self.assertEqual(before.targets, commander._build_blue_observation().targets)

    def test_due_assignment_uses_prediction_and_expires(self):
        engine = create_engine()
        factory = engine.simulator_factory
        factory.blue_information = self.make_store()
        commander = factory.get_simulators_by_type(35000)[0]
        track = max(self.tracks, key=lambda item: item.detect_time)
        interceptor = factory.get_simulators_by_type(24000)[0]
        assignment = ScheduledInterceptorAssignment(
            interceptor_id=interceptor.entity_ext.entity.id, target_id=track.target_id,
            target_pos_ecf=track.pos_ecf, target_vel_ecf=track.vel_ecf,
            decision_time=self.engine.sim_time, planned_launch_time=self.engine.sim_time + 60_000,
            estimated_intercept_time=self.engine.sim_time + 70_000,
        )
        commander.sim_time = self.engine.sim_time + 1000
        current = commander._current_assignment(assignment)
        predicted = factory.blue_information.get_track(track.target_id, commander.sim_time)
        self.assertEqual(current.target_pos_ecf, predicted.pos_ecf)
        commander.pending_launches = {assignment.interceptor_id: assignment}
        commander.sim_time = track.detect_time + 30_001
        commander._execute_due_launches()
        self.assertIsNone(commander._current_assignment(assignment))
        self.assertEqual(commander.pending_launches, {})

    def test_all_ten_policies_receive_identical_information(self):
        observation = self.make_store().snapshot(self.engine.sim_time)
        target_ids = {track.target_id for track in observation.targets}
        interceptor_ids = {item.interceptor_id for item in observation.interceptors if item.available}
        for name in BLUE_POLICY_CHOICES:
            with self.subTest(policy=name):
                controller = BlueDefenseController(BlueDefenseConfig(policy_name=name, seed=42))
                decision = controller.decide(observation)
                self.assertIsNotNone(decision)
                for assignment in decision.assignments:
                    self.assertIn(assignment.target_id, target_ids)
                    self.assertIn(assignment.interceptor_id, interceptor_ids)
                controller.reset()

    def test_interceptor_guidance_ignores_hidden_position_changes(self):
        engine = create_engine()
        factory = engine.simulator_factory
        factory.blue_information = self.make_store()
        track = self.tracks[0]
        first, second = factory.get_simulators_by_type(24000)[:2]
        position = first.entity_ext.entity.lla
        second.set_lla(Vector3d(position.x, position.y, position.z))
        for interceptor in (first, second):
            interceptor.sim_time = self.engine.sim_time
            interceptor.launch(track.target_id,
                               Vector3D(track.pos_ecf.x, track.pos_ecf.y, track.pos_ecf.z),
                               Vector3D(track.vel_ecf.x, track.vel_ecf.y, track.vel_ecf.z))
        first.set_target_ecf()
        entity = factory.get_simulator_by_id(track.target_id).entity_ext.entity
        factory.modify_simulator_position(track.target_id, {
            "x": entity.lla.x + 1.0, "y": entity.lla.y + 1.0, "z": entity.lla.z,
        })
        second.set_target_ecf()
        for _ in range(20):
            first.model.Update()
            second.model.Update()
        self.assert_same_native_state(first, second)
        first.sim_time = second.sim_time = max(item.detect_time for item in self.tracks) + 30_001
        first.set_target_ecf()
        second.set_target_ecf()
        for _ in range(20):
            first.model.Update()
            second.model.Update()
        self.assert_same_native_state(first, second)

    def assert_same_native_state(self, first, second):
        for vector_name in ("posEcf", "velEcf"):
            left = getattr(first.model.getState(), vector_name)()
            right = getattr(second.model.getState(), vector_name)()
            for axis in ("x", "y", "z"):
                self.assertAlmostEqual(getattr(left, axis)(), getattr(right, axis)(), places=7)

    def test_b7_to_b9_release_without_new_record_and_cancel_expired_targets(self):
        for name in BLUE_POLICY_CHOICES[7:]:
            with self.subTest(policy=name):
                information = self.make_store()
                policy = build_blue_policy(BlueDefenseConfig(policy_name=name, seed=42))
                policy.decide(information.snapshot(self.engine.sim_time))
                released = policy.decide(information.snapshot(self.engine.sim_time + 10_000))
                self.assertTrue(released)
                for assignment in released:
                    expected = information.get_track(assignment.target_id, self.engine.sim_time + 10_000)
                    self.assertEqual(assignment.target_pos_ecf, expected.pos_ecf)
                information = self.make_store()
                policy.reset()
                policy.decide(information.snapshot(self.engine.sim_time))
                expiry = max(track.detect_time for track in self.tracks) + 30_001
                self.assertEqual(policy.decide(information.snapshot(expiry)), [])

    def test_engine_reset_clears_database_and_controller_plans(self):
        engine = create_engine(BLUE_POLICY_CHOICES[7])
        place_sensor_targets(engine)
        advance_until_detected(engine)
        self.assertTrue(engine.simulator_factory.blue_information.snapshot(engine.sim_time).targets)
        engine.reset()
        factory = engine.simulator_factory
        commander = factory.get_simulators_by_type(35000)[0]
        self.assertEqual(factory.blue_information.snapshot(0).targets, ())
        self.assertEqual(commander.pending_launches, {})
        self.assertEqual(commander.launched_list, {})

    def test_mother_and_sentinel_evasion_use_database(self):
        engine = create_engine()
        factory = engine.simulator_factory
        track = self.make_store().snapshot(self.engine.sim_time).targets[0]
        for entity_type in (9400, 9600):
            with self.subTest(entity_type=entity_type):
                ship = factory.get_simulators_by_type(entity_type)[0]
                ship.sim_time = self.engine.sim_time
                ship.entity_ext.entity.posEcf = Vector3d(track.pos_ecf.x + 1000, track.pos_ecf.y, track.pos_ecf.z)
                factory.blue_information = BlueInformationStore()
                ship.detect_attacker()
                self.assertIsNone(ship._attacker)
                factory.blue_information = self.make_store()
                ship.detect_attacker()
                self.assertIsNotNone(ship._attacker)
                self.assertIsNotNone(ship._perpendicular_velocity())
                ship.sim_time = max(item.detect_time for item in self.tracks) + 30_001
                ship.detect_attacker()
                self.assertIsNone(ship._attacker)

    def test_each_policy_launches_through_native_engine(self):
        results = []
        for name in BLUE_POLICY_CHOICES:
            with self.subTest(policy=name):
                engine = create_engine(name)
                place_sensor_targets(engine)
                advance_until_detected(engine)
                factory = engine.simulator_factory
                for _ in range(20):
                    engine.step([])
                commander = factory.get_simulators_by_type(35000)[0]
                commander.sim_time = engine.sim_time
                observation = commander._build_blue_observation()
                self.assertEqual(observation.targets, factory.blue_information.snapshot(engine.sim_time).targets)
                launched_ids = {entity_id for ids in commander.launched_list.values() for entity_id in ids}
                self.assertEqual(len(launched_ids), sum(map(len, commander.launched_list.values())))
                native_launches = sum(unit.launched == 1 for unit in factory.get_simulators_by_type(24000))
                self.assertGreater(native_launches, 0)
                self.assertEqual(native_launches, len(launched_ids))
                self.assertEqual(native_launches, commander.coordination_metrics["actual_launches"])
                results.append({"policy": name, "steps_executed": engine.current_step,
                                "simulation_time_ms": engine.sim_time, "known_targets": len(observation.targets),
                                "native_launches": native_launches, "pending_launches": len(commander.pending_launches)})
        (ROOT / ".blue_validation/native_policies.json").write_text(
            json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8",
        )


if __name__ == "__main__":
    unittest.main()
