"""Dependency-free deployment checks for the red learning motion layer."""

from __future__ import annotations

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from user_agents.red.learning import (
    LearningActionAdapter,
    ObservationEncoder,
    build_learning_motion_policy,
)


class RedLearningRuntimeTests(unittest.TestCase):
    def test_random_masked_policy_and_action_adapter_are_runtime_safe(self) -> None:
        initial = {
            "entities": {
                "101": {
                    "type": 9400,
                    "position": {"lon": 118.5, "lat": 22.0, "alt": 0.0},
                    "nameChn": "母巢_101",
                }
            }
        }
        adapter = LearningActionAdapter()
        encoder = ObservationEncoder(initial, agent_id=1)
        observation = {
            "step": 1,
            "self": {
                "position": {"lon": 118.0, "lat": 22.0, "alt": 100.0},
                "health": 100.0,
                "type": 21000,
                "detectInfo": {},
                "commRangeInfo": [],
            },
        }
        policy = build_learning_motion_policy("random_masked", seed=7)
        action = policy.select_action(
            encoder.encode(
                observation,
                launched=True,
                launch_step=0,
                satellite_used=False,
                maneuver_state=0,
            ),
            adapter.build_action_mask(),
        )
        engine_action = adapter.to_engine_action(action, entity_id=1)
        self.assertEqual(engine_action.shape, (1, 4))
        self.assertEqual(engine_action[0, 1], 1.0)
        self.assertTrue(np.isin(engine_action[0, 2], [-1.0, 0.0, 1.0]))
        self.assertFalse(hasattr(adapter, "launch_target"))

    def test_checkpointed_policy_requires_an_explicit_model(self) -> None:
        with self.assertRaisesRegex(ValueError, "--red-learning-model"):
            build_learning_motion_policy("mappo")

    def test_hierarchical_encoder_appends_only_legal_task_context(self) -> None:
        initial = {"entities": {}}
        encoder = ObservationEncoder(initial, agent_id=1, hierarchical_task_context=True)
        encoded = encoder.encode(
            {
                "step": 1,
                "self": {
                    "position": {"lon": 118.0, "lat": 22.0, "alt": 100.0},
                    "health": 100.0,
                    "type": 21000,
                    "detectInfo": {},
                    "commRangeInfo": [],
                },
            },
            launched=True,
            launch_step=0,
            satellite_used=False,
            maneuver_state=0,
            task_context=(1.0, 0.0, 0.0, 0.25, 0.5),
        )
        self.assertEqual(encoder.observation_dim, 90)
        np.testing.assert_allclose(encoded[-5:], [1.0, 0.0, 0.0, 0.25, 0.5])

    def test_actor_catalogue_excludes_hidden_priors_and_reads_received_track_types(self):
        initial = {"entities": {
            "101": {"type": 9400, "position": {"lon": 118.5, "lat": 22.0}},
            "103": {"type": 9500, "position": {"lon": 121.0, "lat": 22.0}},
        }}
        encoder = ObservationEncoder(initial)
        self.assertEqual([item["entity_id"] for item in encoder.targets], [101])
        encoded = encoder.encode({
            "step": 1,
            "self": {
                "position": {"lon": 118.0, "lat": 22.0}, "type": 21000,
                "health": 100, "commRangeInfo": [1],
                "detectInfo": {103: {"entity_id": 103, "entity_type": 9500}},
            },
        }, launched=True, launch_step=1, satellite_used=False, maneuver_state=0)
        self.assertEqual(encoder.observation_dim, 85)
        np.testing.assert_allclose(encoded[-4:], [1 / 200, 0, 1 / 10, 1 / 64])


if __name__ == "__main__":
    unittest.main()
