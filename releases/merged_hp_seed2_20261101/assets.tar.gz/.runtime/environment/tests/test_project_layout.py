"""Runtime boundaries and entry points in the flat project layout."""

from __future__ import annotations

import json
import os
from contextlib import chdir, redirect_stderr
from io import StringIO
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scenarios import CASES_ROOT, SCENARIO_ROOT, load_scenario, resolve_scenario_path
from main import build_blue_config, build_parser, main, prepare_run


class ProjectLayoutTests(unittest.TestCase):
    def test_runtime_domains_are_separate(self):
        for package in ("envengine", "user_agents", "blue_defense", "scenarios", "evaluation"):
            self.assertTrue((ROOT / package).is_dir(), package)
        self.assertTrue((ROOT / "main.py").is_file())
        self.assertTrue((ROOT / "user_agents" / "red").is_dir())
        self.assertEqual(SCENARIO_ROOT, ROOT / "scenarios")
        self.assertFalse((ROOT / "user_agents" / "blue").exists())
        for obsolete in ("core", "policies", "grid_maps", "tools", "experiments", "ui"):
            self.assertFalse((ROOT / obsolete).exists(), obsolete)
        self.assertFalse((ROOT / "scenario.json").exists())
        self.assertTrue((SCENARIO_ROOT / "scenario.json").is_file())
        for obsolete in ("run.py", "run_local.cmd", "run_local.ps1"):
            self.assertFalse((ROOT / obsolete).exists(), obsolete)

    def test_scene_id_uses_project_catalogue(self):
        bundle = load_scenario("launch20/easy/E01")
        self.assertEqual(bundle.path, CASES_ROOT / "launch20/easy/E01/scenario.json")
        self.assertTrue(bundle.deployment_area["all_units_depart_at_start"])
        self.assertFalse(bundle.deployment_area["grid_required"])
        self.assertEqual(bundle.reward_policy.max_steps, 3000)
        self.assertIsNotNone(bundle.case_info)

    def test_bundled_scene_paths_are_cwd_independent(self):
        self.assertEqual(resolve_scenario_path("default"), SCENARIO_ROOT / "platform.json")
        self.assertEqual(resolve_scenario_path("./scenarios/platform.json"), SCENARIO_ROOT / "platform.json")
        self.assertEqual(resolve_scenario_path("scenario.json"), SCENARIO_ROOT / "scenario.json")

    def test_external_scene_without_metadata(self):
        # The loader resolves arbitrary scene files; the engine validates their schema.
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "scenario.json"
            path.write_text(json.dumps({"example": True}), encoding="utf-8")
            bundle = load_scenario(path)
            self.assertEqual(bundle.path, path.resolve())
            self.assertIsNone(bundle.reward_policy)
            self.assertIsNone(bundle.deployment_area)

    def test_missing_scene_reports_input(self):
        with self.assertRaisesRegex(ValueError, "no-such-scene"):
            load_scenario("no-such-scene")

    def test_entry_uses_scene_limit_and_one_round_by_default(self):
        args = build_parser().parse_args(["--scenario", "launch20/easy/E01"])
        bundle = prepare_run(args)
        self.assertEqual(bundle.path, resolve_scenario_path("launch20/easy/E01"))
        self.assertEqual(args.max_steps, 3000)
        self.assertEqual(args.total_rounds, 1)
        self.assertEqual(args.output_dir, ROOT / "results/runs/manual")
        args = build_parser().parse_args(["--scenario", "launch20/easy/E01", "--max-steps=2"])
        prepare_run(args)
        self.assertEqual(args.max_steps, 2)

    def test_scene_without_scoring_uses_fallback_limit(self):
        args = build_parser().parse_args(["--scenario", "https://example.invalid/scenario.json"])
        prepare_run(args)
        self.assertEqual(args.max_steps, 1000)

    def test_run_from_outside_project_keeps_caller_paths_without_subprocess(self):
        with tempfile.TemporaryDirectory() as folder, chdir(folder):
            caller_root = Path.cwd()
            Path("deployment.json").write_text("{}", encoding="utf-8")
            with patch("main.run_simulation") as execute:
                self.assertEqual(main([
                    "--scenario", "launch20/easy/E01", "--seed", "7",
                    "--deployment-plan", "deployment.json", "--max-steps", "2",
                    "--output-dir", "my-results",
                ]), 0)
            self.assertEqual(Path.cwd(), caller_root)

        execute.assert_called_once()
        args, bundle = execute.call_args.args
        self.assertEqual(bundle.path, CASES_ROOT / "launch20/easy/E01/scenario.json")
        self.assertEqual(args.deployment_plan, caller_root / "deployment.json")
        self.assertEqual(args.output_dir, caller_root / "my-results")
        self.assertEqual(args.max_steps, 2)
        self.assertEqual(args.seed, 7)

    def test_cli_rejects_removed_wrappers_and_subcommands(self):
        parser = build_parser()
        for argv in (["ui"], ["run"], ["--run-id", "demo"], ["--", "--max-steps", "2"]):
            with self.subTest(argv=argv), redirect_stderr(StringIO()), self.assertRaises(SystemExit) as error:
                parser.parse_args(argv)
            self.assertEqual(error.exception.code, 2)

    def test_cli_rejects_invalid_numeric_settings(self):
        parser = build_parser()
        for argv in (
            ["--total-rounds", "0"], ["--max-steps", "-1"],
            ["--batch-size", "0"], ["--log-frequency", "0"],
            ["--blue-wave-size", "0"], ["--blue-plan-delay", "nan"],
            ["--blue-wave-gap", "-1"],
        ):
            with self.subTest(argv=argv), redirect_stderr(StringIO()), self.assertRaises(SystemExit):
                parser.parse_args(argv)

    def test_learning_combinations_are_checked_before_native_execution(self):
        for argv in (
            ["--red-policy", "r9_hierarchical_learning"],
            ["--red-motion-policy", "ppo"],
            ["--red-learning-train"],
            ["--red-learning-model", "model.pt"],
            ["--seed", "-1"],
        ):
            with self.subTest(argv=argv), self.assertRaises(ValueError):
                prepare_run(build_parser().parse_args(argv))
        args = build_parser().parse_args([
            "--red-policy", "r9_hierarchical_learning", "--red-motion-policy", "random_masked",
        ])
        prepare_run(args)

    def test_blue_config_has_one_explicit_source_and_seconds_are_converted(self):
        args = build_parser().parse_args([
            "--scenario", "launch20/easy/E01", "--blue-policy", "b9_min_cost_planned_multi_wave",
            "--blue-plan-delay", "2", "--blue-wave-gap", "3",
            "--blue-min-cost-decision-interval", "0.25", "--seed", "7",
        ])
        config = build_blue_config(args, prepare_run(args))
        self.assertEqual(config.planning_delay_ms, 2000)
        self.assertEqual(config.wave_gap_ms, 3000)
        self.assertEqual(config.min_cost_decision_interval_ms, 250)
        self.assertEqual(config.seed, 7)
        self.assertTrue(config.asset_values)

    def test_blue_wave_defaults_follow_selected_policy_and_allow_explicit_override(self):
        from blue_defense.registry import build_blue_policy

        for name, expected_gap in (
            ("b8_threat_multi_wave", 10000),
            ("b9_min_cost_planned_multi_wave", 5000),
        ):
            for override in (None, "0", "5"):
                with self.subTest(policy=name, override=override):
                    argv = ["--scenario", "launch20/easy/E03", "--blue-policy", name]
                    if override is not None:
                        argv += ["--blue-wave-gap", override]
                    args = build_parser().parse_args(argv)
                    config = build_blue_config(args, prepare_run(args))
                    policy = build_blue_policy(config)
                    expected = expected_gap if override is None else float(override) * 1000
                    self.assertEqual(policy.wave_gap, expected)
                    if name == "b9_min_cost_planned_multi_wave":
                        self.assertEqual(policy.planning_delay, 1000)
        args = build_parser().parse_args([
            "--scenario", "launch20/easy/E03", "--blue-policy", "b7_planned_nearest",
        ])
        self.assertEqual(build_blue_policy(build_blue_config(args, prepare_run(args))).planning_delay, 1000)

    def test_environment_variables_do_not_override_cli_or_blue_policies(self):
        from blue_defense import B7PlannedNearestPolicy, B8ThreatMultiWavePolicy, B9MinCostPlannedMultiWavePolicy

        with patch.dict(os.environ, {
            "RED_POLICY": "not-a-policy", "SIMULATION_SEED": "55",
            "BLUE_POLICY": "not-a-policy", "BLUE_PLAN_DELAY": "99999",
            "BLUE_WAVE_GAP": "99999", "BLUE_WAVE_SIZE": "99",
        }):
            args = build_parser().parse_args([])
            config = build_blue_config(args, prepare_run(args))
            self.assertEqual(args.red_policy, "r0_random")
            self.assertIsNone(args.seed)
            self.assertEqual(config.policy_name, "b0_fixed_ratio_random")
            self.assertEqual(config.planning_delay_ms, 1000)
            self.assertEqual(B7PlannedNearestPolicy().planning_delay, 1000)
            self.assertEqual(B8ThreatMultiWavePolicy().wave_size, 1)
            self.assertEqual(B9MinCostPlannedMultiWavePolicy().wave_gap, 5000)

    def test_remote_scene_is_left_to_engine_loader(self):
        bundle = load_scenario("https://example.invalid/scenario.json")
        self.assertEqual(bundle.path, "https://example.invalid/scenario.json")
        self.assertIsNone(bundle.case_info)

    def test_configuration_imports_do_not_load_native_engine(self):
        script = (
            "import sys; "
            f"sys.path.insert(0, {str(ROOT)!r}); "
            "import blue_defense, user_agents.red, scenarios, main; "
            "from user_agents.red import RedAgentConfig, RedAgentFactory; "
            "assert '--max-steps' in main.build_parser().format_help(); "
            "assert 'envengine' not in sys.modules; "
            "assert 'torch' not in sys.modules; "
            "assert 'scipy' not in sys.modules; "
            "assert len(blue_defense.BLUE_POLICY_CHOICES) == 10"
        )
        result = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_help_runs_from_outside_project(self):
        with tempfile.TemporaryDirectory() as folder:
            result = subprocess.run(
                [sys.executable, str(ROOT / "main.py"), "--help"],
                cwd=folder, capture_output=True, text=True,
            )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("--blue-policy", result.stdout)
        self.assertIn("--total-rounds", result.stdout)

    def test_entry_registers_factory_agents_using_public_data_only(self):
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(
            mapArea=SimpleNamespace(lonMin=0, lonMax=10, latMin=0, latMax=10),
        ))
        simulator = SimpleNamespace(entity_ext=SimpleNamespace(
            entity=SimpleNamespace(id=11, entityType=21000),
        ))
        env = MagicMock()
        env.engine.simulator_factory.get_all_simulators.return_value = [simulator]
        env.engine.simulator_factory.get_simulators_by_type.return_value = []
        public = {"entities": {9401: {"type": 9400, "position": {"lon": 5, "lat": 5}}}}
        env.get_public_targets_observation.return_value = public
        env.reset.return_value = {"entities": {}}
        env.step.return_value = ({"entities": {}}, {}, True, {})
        agent, deploy = object(), object()
        factory = MagicMock()
        factory.create_agents.return_value = [agent]
        factory.create_deploy_agent.return_value = deploy
        with (
            patch("main.read_profile", return_value=profile),
            patch("main.resolve_deployment_constraints", return_value=([], [], None)),
            patch("envengine.TrainingEnv", return_value=env),
            patch("user_agents.red.RedAgentFactory", return_value=factory) as create_factory,
            patch("envengine.sdk.log.LogManager"),
            patch("envengine.sdk.writer.init_writer"),
            patch("envengine.sdk.writer.write_immediately"),
            patch("evaluation.RunSummary") as summary,
            patch("builtins.print"),
        ):
            summary.return_value.build.return_value = {}
            main(["--seed", "7", "--max-steps", "1", "--render-mode", "none",
                  "--red-policy", "r1_priority", "--red-motion-policy", "straight"])
        config = create_factory.call_args.args[0]
        self.assertEqual((config.policy_name, config.motion_policy, config.seed, config.max_steps),
                         ("r1_priority", "straight", 7, 1))
        self.assertEqual(factory.create_agents.call_args.args[0], public)
        self.assertEqual(tuple(factory.create_agents.call_args.args[1]), ((1, 11),))
        self.assertEqual([call.args[0] for call in env.agent_manager.register_agent.call_args_list],
                         [agent, deploy])
        for name in ("set_team_controller_factory", "set_shared_learning_policy", "set_agent_runtime"):
            getattr(env, name).assert_not_called()
        factory.begin_training_step.assert_not_called()
        factory.finish_training_step.assert_not_called()

    def test_training_switch_delegates_to_user_agent_entry(self):
        with tempfile.TemporaryDirectory() as folder, patch("user_agents.red.train.run_training") as train:
            checkpoint = Path(folder) / "model.pt"
            self.assertEqual(main([
                "--seed", "7", "--max-steps", "1", "--red-motion-policy", "ppo",
                "--red-learning-train", "--red-learning-model", str(checkpoint),
            ]), 0)
        train.assert_called_once()
        args, bundle = train.call_args.args
        self.assertTrue(args.red_learning_train)
        self.assertEqual(args.red_learning_model, checkpoint)
        self.assertIsNotNone(bundle.path)

    def test_illegal_action_propagates_and_resources_close_without_summary(self):
        from envengine.action_validation import IllegalActionError

        profile = SimpleNamespace(imagineProfile=SimpleNamespace(
            mapArea=SimpleNamespace(lonMin=0, lonMax=10, latMin=0, latMax=10),
        ))
        env = MagicMock()
        env.engine.simulator_factory.get_all_simulators.return_value = []
        env.engine.simulator_factory.get_simulators_by_type.return_value = []
        env.get_public_targets_observation.return_value = {"entities": {}}
        env.reset.return_value = {"entities": {}}
        env.step.side_effect = IllegalActionError("target is outside the communication domain")
        writer = MagicMock()
        with (
            patch("main.read_profile", return_value=profile),
            patch("main.resolve_deployment_constraints", return_value=([], [], None)),
            patch("envengine.TrainingEnv", return_value=env),
            patch("envengine.sdk.log.LogManager"),
            patch("envengine.sdk.writer.init_writer", return_value=writer),
            patch("evaluation.RunSummary") as summary,
            self.assertRaisesRegex(IllegalActionError, "communication domain"),
        ):
            main(["--seed", "7", "--max-steps", "2", "--render-mode", "none"])
        env.close.assert_called_once()
        writer.close.assert_called_once()
        summary.return_value.write.assert_not_called()

    def test_cli_limit_overrides_engine_limit_and_reports_termination_reason(self):
        profile = SimpleNamespace(imagineProfile=SimpleNamespace(
            mapArea=SimpleNamespace(lonMin=0, lonMax=10, latMin=0, latMax=10),
        ))
        for limit, steps, reason in ((5000, 1, "environment_done"), (2, 2, "time_limit")):
            with self.subTest(limit=limit):
                env = MagicMock(max_steps=3000)
                env.engine.simulator_factory.get_all_simulators.return_value = []
                env.engine.simulator_factory.get_simulators_by_type.return_value = []
                env.get_public_targets_observation.return_value = {"entities": {}}
                env.reset.return_value = {"entities": {}}
                env.step.side_effect = [({}, 0, index == steps - 1, {}) for index in range(steps)]
                with (
                    patch("main.read_profile", return_value=profile),
                    patch("main.resolve_deployment_constraints", return_value=([], [], None)),
                    patch("envengine.TrainingEnv", return_value=env),
                    patch("envengine.sdk.log.LogManager"),
                    patch("envengine.sdk.writer.init_writer"),
                    patch("envengine.sdk.writer.write_immediately"),
                    patch("evaluation.RunSummary") as summary,
                    patch("builtins.print"),
                ):
                    summary.return_value.build.return_value = {}
                    main(["--scenario", "launch20/easy/E01", "--seed", "7",
                          "--max-steps", str(limit), "--render-mode", "none"])
                self.assertEqual(env.max_steps, limit)
                self.assertEqual(summary.return_value.build.call_args.kwargs["termination_reason"], reason)


if __name__ == "__main__":
    unittest.main()
