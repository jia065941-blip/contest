"""Information-flow regressions between the engine and red planners."""

from copy import deepcopy
from types import SimpleNamespace
import unittest

import numpy as np

from envengine.action_validation import IllegalActionError
from envengine.agent_manager import AgentManager
from envengine.environment.command_converter import CommandConverter
from envengine.environment.training_env import TrainingEnv
from user_agents.red import Position, RedAgentConfig, RedAgentFactory


def track(entity_id=9501, x=1.5, time=1, entity_type=9500):
    return {"entity_id": entity_id, "entity_type": entity_type, "time": time,
            "lla": {"x": x, "y": 1.5, "z": 0.0}}


def own(x=1.0, tracks=None):
    return {"type": 21002, "side": 0, "health": 1.0, "isVisible": True,
            "position": {"lon": x, "lat": 1.0, "alt": 3000.0},
            "detectInfo": deepcopy(tracks or {}), "commRangeInfo": {}}


class CommunicationScopedPlanningTests(unittest.TestCase):
    def make_env(self, groups=((1,), (2,)), left_tracks=None, right_tracks=None):
        env = object.__new__(TrainingEnv)
        env.agent_manager = AgentManager()
        factory = RedAgentFactory(RedAgentConfig(
            policy_name="r1_priority", motion_policy="straight", seed=7,
        ))
        for agent in factory.create_agents(
            {"entities": {9401: {"type": 9400, "position": {"lon": 2.5, "lat": 2.5}}}},
            ((1, 1), (2, 2)),
            search_polygon=(Position(0, 0), Position(3, 0), Position(3, 3), Position(0, 3)),
        ):
            env.agent_manager.register_agent(agent)
        self.groups = groups
        self.full = {"step": 0, "entities": {1: own(tracks=left_tracks), 2: own(2.0, right_tracks)}}

        def refresh_communications():
            for entity_id, entity in self.full["entities"].items():
                group = next(item for item in self.groups if entity_id in item)
                entity["commRangeInfo"] = {
                    member: {"position": deepcopy(self.full["entities"][member]["position"])}
                    for member in group if member != entity_id
                }
            return self.groups

        env.engine = SimpleNamespace(
            refresh_red_communications=refresh_communications,
            simulator_factory=SimpleNamespace(is_using_satellite=lambda: False),
        )
        env._get_observation = lambda: deepcopy(self.full)
        return env

    def test_disconnected_planner_cannot_assign_another_groups_hidden_target(self):
        env = self.make_env(left_tracks={9501: track()})
        commands = env._generate_actions_from_agents()
        by_id = {item["executor_id"]: item for item in commands}
        self.assertEqual(by_id[1]["intent"], "track")
        self.assertEqual(by_id[1]["target_id"], 9501)
        self.assertEqual(by_id[2]["intent"], "search")
        first = env.agent_manager.get_agent(1)._commander
        second = env.agent_manager.get_agent(2)._commander
        self.assertIsNot(first, second)
        self.assertNotIn(9501, {item.entity_id for item in second.targets})
        self.assertEqual(set(second.reports), {2})

    def test_connected_members_share_one_planner_and_stable_groups_keep_it(self):
        received = {9501: track()}
        env = self.make_env(((1, 2),), received, received)
        env._generate_actions_from_agents()
        controller = env.agent_manager.get_agent(1)._commander
        self.assertIs(controller, env.agent_manager.get_agent(2)._commander)
        self.full["step"] = 1
        env._generate_actions_from_agents()
        self.assertIs(controller, env.agent_manager.get_agent(1)._commander)

    def test_split_preserves_received_memory_without_new_cross_group_updates(self):
        received = {9501: track(x=1.5)}
        env = self.make_env(((1, 2),), received, received)
        env._generate_actions_from_agents()
        previous = env.agent_manager.get_agent(1)._commander
        self.groups = ((1,), (2,))
        self.full["step"] = 20
        self.full["entities"][1]["detectInfo"][9501] = track(x=2.7, time=20)
        env._generate_actions_from_agents()
        first = env.agent_manager.get_agent(1)._commander
        second = env.agent_manager.get_agent(2)._commander
        self.assertIsNot(first, previous)
        self.assertIsNot(second, previous)
        self.assertEqual(next(t.position.lon for t in first.targets if t.entity_id == 9501), 2.7)
        self.assertEqual(next(t.position.lon for t in second.targets if t.entity_id == 9501), 1.5)

    def test_merge_replans_from_newly_authorized_received_tracks(self):
        env = self.make_env(left_tracks={9501: track()})
        env._generate_actions_from_agents()
        previous = env.agent_manager.get_agent(2)._commander
        self.groups = ((1, 2),)
        self.full["step"] = 20
        self.full["entities"][2]["detectInfo"] = {9501: track()}
        commands = env._generate_actions_from_agents()
        controller = env.agent_manager.get_agent(2)._commander
        self.assertIsNot(controller, previous)
        self.assertIs(controller, env.agent_manager.get_agent(1)._commander)
        self.assertTrue(all(item["intent"] == "track" for item in commands))

    def test_disconnected_r9_context_does_not_include_other_groups_threat(self):
        env = self.make_env(left_tracks={2401: track(2401, entity_type=24000)})
        env._generate_actions_from_agents()
        first = env.agent_manager.get_agent(1)._commander
        second = env.agent_manager.get_agent(2)._commander
        self.assertGreater(first.learning_task_context(1)[3], 0.0)
        self.assertEqual(second.learning_task_context(2)[3], 0.0)

    def test_independent_factories_do_not_share_same_id_group_state(self):
        env = self.make_env()
        env._generate_actions_from_agents()
        first = env.agent_manager.get_agent(1)._commander
        other = self.make_env(left_tracks={9501: track()})
        other._generate_actions_from_agents()
        second = other.agent_manager.get_agent(1)._commander
        self.assertIsNot(first, second)
        self.assertNotIn(9501, {item.entity_id for item in first.targets})
        self.assertIn(9501, {item.entity_id for item in second.targets})

    def test_forged_observation_does_not_mutate_authoritative_snapshot(self):
        env = self.make_env(left_tracks={9501: track()})
        isolated = env.agent_manager.extract_observation_for_agent(self.full, 1)
        isolated["self"]["detectInfo"][9501]["lla"]["x"] = 999
        isolated["self"]["commRangeInfo"][2] = {}
        self.assertEqual(self.full["entities"][1]["detectInfo"][9501]["lla"]["x"], 1.5)
        self.assertEqual(self.full["entities"][1]["commRangeInfo"], {})

    def test_report_copy_cannot_be_changed_after_set_observation(self):
        env = self.make_env(left_tracks={9501: track()})
        agent = env.agent_manager.get_agent(1)
        observation = env.agent_manager.extract_observation_for_agent(self.full, 1)
        agent.set_observation(observation)
        observation["self"]["detectInfo"][9501]["lla"]["x"] = 999
        actions = agent.get_action()
        self.assertEqual(int(actions[0, 2]), 9501)
        self.assertEqual(next(item.position.lon for item in agent._commander.targets
                              if item.entity_id == 9501), 1.5)

    def test_agent_cannot_issue_command_for_another_executor(self):
        env = self.make_env()
        agent = env.agent_manager.get_agent(1)
        agent.get_action = lambda: np.array([[4, 2, 9501, 0]])
        with self.assertRaisesRegex(IllegalActionError, "只能控制自身"):
            env._generate_actions_from_agents()


class RedActionProtocolTests(unittest.TestCase):
    def test_target_action_has_id_without_player_supplied_position(self):
        result = CommandConverter.common_converter([[[4, 1, 9501, 0]]])[0]
        self.assertEqual(result["intent"], "track")
        self.assertEqual(result["target_id"], 9501)
        self.assertIsNone(result["target"])

    def test_search_action_is_explicit_navigation(self):
        result = CommandConverter.common_converter([[[2, 1, 1.5, 2.5]]])[0]
        self.assertEqual(result["intent"], "search")
        self.assertEqual(result["target"], {"x": 1.5, "y": 2.5, "z": 0.0})
        self.assertIsNone(result["target_id"])

    def test_legacy_launch_and_malformed_actions_fail(self):
        for row in ([1, 1, 1, 0], [999, 1, 0, 0], [4, 1, 95.5, 0],
                    [2, 1, float("nan"), 0], [4, 1.5, 9501, 0], [2, 1, 2]):
            with self.subTest(row=row), self.assertRaises(IllegalActionError):
                CommandConverter.common_converter([[row]])


if __name__ == "__main__":
    unittest.main()
