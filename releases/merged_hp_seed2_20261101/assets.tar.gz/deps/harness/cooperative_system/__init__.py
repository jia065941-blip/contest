"""Cross-type evidence, non-owning skill proposals and contextual system arbitration."""
