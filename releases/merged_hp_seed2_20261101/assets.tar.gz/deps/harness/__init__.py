"""Project-local competition Harness; independent of the original source checkout."""
